#!/usr/bin/env python3
"""
OSINT Framework - GUI Version
Educational Tool | Ethical Use Only
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import socket
import concurrent.futures
import datetime
import os
import sys

# ─────────────────────────────────────────────
#  COLOR THEME
# ─────────────────────────────────────────────
BG        = "#0d1117"
BG2       = "#161b22"
BG3       = "#21262d"
ACCENT    = "#00ff9f"
ACCENT2   = "#00bfff"
RED       = "#ff4c4c"
YELLOW    = "#ffd700"
FG        = "#e6edf3"
FG2       = "#8b949e"
FONT_MONO = ("Consolas", 10)
FONT_UI   = ("Segoe UI", 10)
FONT_BIG  = ("Segoe UI", 12, "bold")

# ─────────────────────────────────────────────
#  MODULES (no DB, free APIs only)
# ─────────────────────────────────────────────

def whois_lookup(target, log):
    log(f"[*] WHOIS Lookup → {target}\n" + "─"*50 + "\n")
    results = {}
    try:
        import whois
        w = whois.whois(target)
        fields = {
            "Domain Name"  : str(w.domain_name),
            "Registrar"    : str(w.registrar),
            "Creation Date": str(w.creation_date),
            "Expiry Date"  : str(w.expiration_date),
            "Updated Date" : str(w.updated_date),
            "Name Servers" : str(w.name_servers),
            "Status"       : str(w.status),
            "Emails"       : str(w.emails),
            "Country"      : str(w.country),
            "DNSSEC"       : str(w.dnssec),
        }
        for k, v in fields.items():
            log(f"  {k:<20}: {v}\n")
            results[k] = v
    except ImportError:
        log("[!] 'whois' library not found. Trying system whois...\n")
        try:
            import subprocess
            out = subprocess.check_output(["whois", target], timeout=10, text=True)
            for line in out.splitlines()[:40]:
                log(f"  {line}\n")
            results["raw"] = out
        except Exception as e:
            log(f"[!] System whois failed: {e}\n")
            results["error"] = str(e)
    except Exception as e:
        log(f"[!] WHOIS error: {e}\n")
        results["error"] = str(e)
    log("\n")
    return results


def dns_lookup(target, log):
    log(f"[*] DNS Lookup → {target}\n" + "─"*50 + "\n")
    results = {}
    try:
        import dns.resolver
        for rtype in ['A', 'MX', 'NS', 'TXT', 'CNAME']:
            try:
                answers = dns.resolver.resolve(target, rtype)
                records = [str(r) for r in answers]
                log(f"  [{rtype}] Records:\n")
                for rec in records:
                    log(f"       {rec}\n")
                results[rtype] = records
            except Exception:
                log(f"  [{rtype}] No records found.\n")
                results[rtype] = []
    except ImportError:
        log("[!] 'dnspython' not found. Using socket fallback...\n")
        try:
            ip = socket.gethostbyname(target)
            log(f"  [A] IP Address: {ip}\n")
            results['A'] = [ip]
            hostname, aliases, ips = socket.gethostbyname_ex(target)
            log(f"  [+] Hostname : {hostname}\n")
            log(f"  [+] Aliases  : {aliases}\n")
            log(f"  [+] All IPs  : {ips}\n")
            results.update({"hostname": hostname, "aliases": aliases, "all_ips": ips})
        except Exception as e:
            log(f"[!] DNS error: {e}\n")
            results["error"] = str(e)
    log("\n")
    return results


COMMON_PORTS = {
    21:"FTP", 22:"SSH", 23:"Telnet", 25:"SMTP", 53:"DNS",
    80:"HTTP", 110:"POP3", 143:"IMAP", 443:"HTTPS", 445:"SMB",
    3306:"MySQL", 3389:"RDP", 5432:"PostgreSQL", 6379:"Redis",
    8080:"HTTP-Alt", 8443:"HTTPS-Alt", 27017:"MongoDB",
}

def _scan_port(host, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.0)
            return port, s.connect_ex((host, port)) == 0
    except:
        return port, False

def port_scanner(target, log):
    log(f"[*] Port Scanner → {target}\n" + "─"*50 + "\n")
    results = {"open": [], "closed": [], "target": target}
    try:
        ip = socket.gethostbyname(target)
        log(f"  [+] Resolved: {target} → {ip}\n\n")
        results['ip'] = ip
    except Exception as e:
        log(f"[!] Could not resolve {target}: {e}\n")
        results['error'] = str(e)
        return results

    log(f"  {'PORT':<8} {'SERVICE':<15} STATUS\n")
    log(f"  {'─'*35}\n")

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as ex:
        futures = {ex.submit(_scan_port, ip, port): port for port in COMMON_PORTS}
        for future in concurrent.futures.as_completed(futures):
            port, is_open = future.result()
            service = COMMON_PORTS[port]
            if is_open:
                log(f"  {port:<8} {service:<15} ✔ OPEN\n")
                results['open'].append({"port": port, "service": service})
            else:
                results['closed'].append(port)

    log(f"\n  [+] Open: {len(results['open'])} | Closed/Filtered: {len(results['closed'])}\n\n")
    return results


DEFAULT_WORDLIST = [
    "www","mail","ftp","webmail","smtp","pop","ns1","ns2","webdisk",
    "cpanel","whm","autodiscover","autoconfig","m","imap","test","ns3",
    "vpn","mail2","new","mysql","old","lists","support","mobile","mx",
    "static","docs","beta","shop","secure","demo","cp","calendar","wiki",
    "web","media","email","images","img","www2","admin","blog","portal",
    "staging","api","dev","download","forums","video","chat",
]

def subdomain_enum(target, wordlist_file, log):
    log(f"[*] Subdomain Enumeration → {target}\n" + "─"*50 + "\n")
    results = {"found": [], "total_checked": 0}

    subdomains = DEFAULT_WORDLIST[:]
    if wordlist_file and os.path.exists(wordlist_file):
        try:
            with open(wordlist_file) as f:
                subdomains = [l.strip() for l in f if l.strip()]
            log(f"  [+] Loaded {len(subdomains)} entries from wordlist.\n\n")
        except Exception as e:
            log(f"  [!] Wordlist read error: {e}. Using default.\n\n")
    else:
        log(f"  [+] Using default wordlist ({len(subdomains)} entries).\n\n")

    for sub in subdomains:
        full = f"{sub}.{target}"
        results['total_checked'] += 1
        try:
            ip = socket.gethostbyname(full)
            log(f"  ✔ FOUND  {full:<40} → {ip}\n")
            results['found'].append({"subdomain": full, "ip": ip})
        except socket.gaierror:
            pass

    log(f"\n  [+] Checked: {results['total_checked']} | Found: {len(results['found'])}\n\n")
    return results


def generate_report(target, results):
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename  = f"osint_report_{target.replace('.','_')}_{timestamp}.txt"
    os.makedirs("reports", exist_ok=True)
    path = os.path.join("reports", filename)
    with open(path, "w") as f:
        f.write("="*60 + "\n        OSINT FRAMEWORK - Recon Report\n" + "="*60 + "\n")
        f.write(f"Target : {target}\nDate   : {datetime.datetime.now()}\n")
        f.write("="*60 + "\n\n")
        for section, data in results.items():
            f.write(f"[+] {section.upper()}\n" + "-"*40 + "\n")
            if isinstance(data, dict):
                for k, v in data.items():
                    f.write(f"  {k}: {v}\n")
            f.write("\n")
        f.write("="*60 + "\n  *** For Educational and Ethical Use Only ***\n" + "="*60 + "\n")
    return path


# ─────────────────────────────────────────────
#  GUI APPLICATION
# ─────────────────────────────────────────────

class OSINTApp:
    def __init__(self, root):
        self.root  = root
        self.root.title("OSINT Framework — Educational Tool")
        self.root.geometry("1050x700")
        self.root.minsize(900, 600)
        self.root.configure(bg=BG)
        self.results = {}
        self._build_ui()

    # ── BUILD UI ──────────────────────────────
    def _build_ui(self):
        self._build_titlebar()
        self._build_target_bar()
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self._build_sidebar(main)
        self._build_output(main)
        self._build_statusbar()

    def _build_titlebar(self):
        bar = tk.Frame(self.root, bg=BG2, height=52)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        tk.Label(bar, text="⬡  OSINT FRAMEWORK", font=("Consolas", 14, "bold"),
                 bg=BG2, fg=ACCENT).pack(side="left", padx=18, pady=12)
        tk.Label(bar, text="Educational Tool — Ethical Use Only",
                 font=FONT_UI, bg=BG2, fg=FG2).pack(side="left")
        tk.Label(bar, text=datetime.datetime.now().strftime("%Y-%m-%d"),
                 font=FONT_UI, bg=BG2, fg=FG2).pack(side="right", padx=18)

    def _build_target_bar(self):
        bar = tk.Frame(self.root, bg=BG3, height=50)
        bar.pack(fill="x", padx=12, pady=8)
        bar.pack_propagate(False)
        tk.Label(bar, text="TARGET:", font=("Consolas", 10, "bold"),
                 bg=BG3, fg=ACCENT).pack(side="left", padx=14, pady=12)
        self.target_var = tk.StringVar()
        entry = tk.Entry(bar, textvariable=self.target_var,
                         font=("Consolas", 12), bg=BG, fg=ACCENT,
                         insertbackground=ACCENT, relief="flat",
                         highlightthickness=1, highlightcolor=ACCENT,
                         highlightbackground=BG3, width=35)
        entry.pack(side="left", ipady=6, padx=(0, 10))
        entry.bind("<Return>", lambda e: self._run_all())

        self._btn(bar, "▶  RUN ALL", self._run_all, ACCENT,  BG).pack(side="left", padx=4)
        self._btn(bar, "💾 SAVE REPORT", self._save_report, YELLOW, BG).pack(side="left", padx=4)
        self._btn(bar, "🗑 CLEAR", self._clear, FG2, BG3).pack(side="left", padx=4)

    def _build_sidebar(self, parent):
        side = tk.Frame(parent, bg=BG2, width=210)
        side.pack(side="left", fill="y", padx=(0, 10))
        side.pack_propagate(False)

        tk.Label(side, text="MODULES", font=("Consolas", 9, "bold"),
                 bg=BG2, fg=FG2).pack(anchor="w", padx=14, pady=(16, 8))

        modules = [
            ("🔍  WHOIS Lookup",        self._run_whois),
            ("🌐  DNS Lookup",           self._run_dns),
            ("🔗  Subdomain Enum",       self._run_subdomain),
            ("🔌  Port Scanner",         self._run_ports),
        ]
        for label, cmd in modules:
            btn = tk.Button(side, text=label, command=cmd,
                            font=FONT_UI, bg=BG3, fg=FG, activebackground=ACCENT,
                            activeforeground=BG, relief="flat", anchor="w",
                            padx=14, pady=10, cursor="hand2")
            btn.pack(fill="x", padx=8, pady=3)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg=ACCENT, fg=BG))
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=BG3,    fg=FG))

        # Wordlist picker
        tk.Frame(side, bg=BG2, height=1).pack(fill="x", padx=8, pady=12)
        tk.Label(side, text="WORDLIST PATH", font=("Consolas", 8, "bold"),
                 bg=BG2, fg=FG2).pack(anchor="w", padx=14, pady=(0, 4))
        self.wordlist_var = tk.StringVar(value="wordlists/subdomains.txt")
        tk.Entry(side, textvariable=self.wordlist_var, font=("Consolas", 8),
                 bg=BG, fg=FG2, insertbackground=ACCENT, relief="flat",
                 highlightthickness=1, highlightcolor=ACCENT,
                 highlightbackground=BG3).pack(fill="x", padx=8, ipady=4)

        # Stats area
        tk.Frame(side, bg=BG2, height=1).pack(fill="x", padx=8, pady=12)
        tk.Label(side, text="SCAN STATS", font=("Consolas", 9, "bold"),
                 bg=BG2, fg=FG2).pack(anchor="w", padx=14)
        self.stats_label = tk.Label(side, text="No scans yet",
                                    font=("Consolas", 8), bg=BG2, fg=FG2,
                                    justify="left", wraplength=190)
        self.stats_label.pack(anchor="w", padx=14, pady=6)

    def _build_output(self, parent):
        out = tk.Frame(parent, bg=BG)
        out.pack(side="left", fill="both", expand=True)

        # Tab bar
        self.tab_frame = tk.Frame(out, bg=BG2)
        self.tab_frame.pack(fill="x")
        self.tabs = {}
        self.current_tab = tk.StringVar(value="OUTPUT")
        for name in ["OUTPUT", "WHOIS", "DNS", "PORTS", "SUBDOMAINS"]:
            self._make_tab(name)

        # Text area
        self.output = scrolledtext.ScrolledText(
            out, font=FONT_MONO, bg=BG, fg=FG,
            insertbackground=ACCENT, relief="flat",
            wrap="word", padx=14, pady=10
        )
        self.output.pack(fill="both", expand=True)
        self.output.tag_config("green",  foreground=ACCENT)
        self.output.tag_config("blue",   foreground=ACCENT2)
        self.output.tag_config("red",    foreground=RED)
        self.output.tag_config("yellow", foreground=YELLOW)
        self.output.tag_config("dim",    foreground=FG2)
        self._welcome()

    def _build_statusbar(self):
        bar = tk.Frame(self.root, bg=BG3, height=26)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        self.status_var = tk.StringVar(value="  Ready — Enter a target and select a module")
        tk.Label(bar, textvariable=self.status_var, font=("Consolas", 8),
                 bg=BG3, fg=FG2, anchor="w").pack(side="left", padx=10)
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=120)
        self.progress.pack(side="right", padx=10, pady=4)

    # ── TABS ──────────────────────────────────
    def _make_tab(self, name):
        btn = tk.Button(self.tab_frame, text=name,
                        font=("Consolas", 9, "bold"), relief="flat",
                        bg=BG2, fg=FG2, padx=14, pady=6, cursor="hand2",
                        command=lambda n=name: self._switch_tab(n))
        btn.pack(side="left")
        self.tabs[name] = btn

    def _switch_tab(self, name):
        self.current_tab.set(name)
        for n, b in self.tabs.items():
            b.config(bg=ACCENT if n == name else BG2,
                     fg=BG    if n == name else FG2)
        self.output.config(state="normal")
        self.output.delete("1.0", "end")
        key = name.lower()
        if name == "OUTPUT":
            self._welcome()
        elif key in self.results:
            self._show_result_tab(name, self.results[key])
        else:
            self._log(f"  No data yet for {name}. Run the module first.\n", "dim")
        self.output.config(state="disabled")

    def _show_result_tab(self, name, data):
        self._log(f"\n  ── {name} Results ──\n\n", "blue")
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, list) and v:
                    self._log(f"  {k}:\n", "green")
                    for item in v:
                        self._log(f"      {item}\n")
                elif v:
                    self._log(f"  {k:<22}: ", "green")
                    self._log(f"{v}\n")

    # ── HELPERS ───────────────────────────────
    def _btn(self, parent, text, cmd, fg, bg):
        b = tk.Button(parent, text=text, command=cmd,
                      font=("Consolas", 9, "bold"), fg=fg, bg=bg,
                      activeforeground=BG, activebackground=fg,
                      relief="flat", padx=12, pady=6, cursor="hand2")
        b.bind("<Enter>", lambda e: b.config(bg=fg, fg=BG))
        b.bind("<Leave>", lambda e: b.config(bg=bg, fg=fg))
        return b

    def _log(self, msg, tag=None):
        self.output.config(state="normal")
        if tag:
            self.output.insert("end", msg, tag)
        else:
            self.output.insert("end", msg)
        self.output.see("end")
        self.output.config(state="disabled")
        self.root.update_idletasks()

    def _clear(self):
        self.output.config(state="normal")
        self.output.delete("1.0", "end")
        self.output.config(state="disabled")
        self.results = {}
        self.stats_label.config(text="No scans yet")
        self._welcome()

    def _welcome(self):
        self._log("""
  ╔══════════════════════════════════════════════════════╗
  ║         OSINT FRAMEWORK  —  Educational Tool        ║
  ║           For Ethical & Academic Use Only            ║
  ╚══════════════════════════════════════════════════════╝

""", "green")
        self._log("  HOW TO USE:\n", "yellow")
        self._log("  1. Enter a domain or IP in the TARGET field above\n")
        self._log("  2. Click a module button on the left — or RUN ALL\n")
        self._log("  3. Results appear here in real-time\n")
        self._log("  4. Click SAVE REPORT to export a .txt report\n\n")
        self._log("  Modules: WHOIS · DNS · Subdomains · Ports\n", "dim")
        self._log("  All free — no API keys required ✔\n\n", "dim")
        self.output.config(state="disabled")

    def _get_target(self):
        t = self.target_var.get().strip()
        if not t:
            messagebox.showwarning("No Target", "Please enter a domain or IP address.")
        return t

    def _busy(self, on, msg=""):
        if on:
            self.progress.start(10)
            self.status_var.set(f"  {msg}")
        else:
            self.progress.stop()
            self.status_var.set("  Done ✔")

    def _update_stats(self):
        lines = []
        if "whois"      in self.results: lines.append("✔ WHOIS")
        if "dns"        in self.results: lines.append("✔ DNS")
        if "ports"      in self.results:
            n = len(self.results["ports"].get("open", []))
            lines.append(f"✔ Ports ({n} open)")
        if "subdomains" in self.results:
            n = len(self.results["subdomains"].get("found", []))
            lines.append(f"✔ Subdomains ({n} found)")
        self.stats_label.config(text="\n".join(lines) if lines else "No scans yet")

    # ── RUNNERS ───────────────────────────────
    def _thread(self, fn):
        threading.Thread(target=fn, daemon=True).start()

    def _run_whois(self):
        t = self._get_target()
        if not t: return
        def _go():
            self._busy(True, "Running WHOIS…")
            self._switch_tab("OUTPUT")
            self._log(f"\n{'─'*60}\n", "dim")
            self.results["whois"] = whois_lookup(t, lambda m: self._log(m))
            self._update_stats()
            self._busy(False)
        self._thread(_go)

    def _run_dns(self):
        t = self._get_target()
        if not t: return
        def _go():
            self._busy(True, "Running DNS Lookup…")
            self._switch_tab("OUTPUT")
            self._log(f"\n{'─'*60}\n", "dim")
            self.results["dns"] = dns_lookup(t, lambda m: self._log(m))
            self._update_stats()
            self._busy(False)
        self._thread(_go)

    def _run_subdomain(self):
        t = self._get_target()
        if not t: return
        def _go():
            self._busy(True, "Running Subdomain Enum…")
            self._switch_tab("OUTPUT")
            self._log(f"\n{'─'*60}\n", "dim")
            wl = self.wordlist_var.get().strip()
            self.results["subdomains"] = subdomain_enum(t, wl, lambda m: self._log(m))
            self._update_stats()
            self._busy(False)
        self._thread(_go)

    def _run_ports(self):
        t = self._get_target()
        if not t: return
        def _go():
            self._busy(True, "Running Port Scanner…")
            self._switch_tab("OUTPUT")
            self._log(f"\n{'─'*60}\n", "dim")
            self.results["ports"] = port_scanner(t, lambda m: self._log(m))
            self._update_stats()
            self._busy(False)
        self._thread(_go)

    def _run_all(self):
        t = self._get_target()
        if not t: return
        def _go():
            self._busy(True, "Running All Modules…")
            self._switch_tab("OUTPUT")
            self._log(f"\n  ▶ Running all modules for: {t}\n\n", "yellow")
            self.results["whois"]      = whois_lookup(t, lambda m: self._log(m))
            self.results["dns"]        = dns_lookup(t, lambda m: self._log(m))
            wl = self.wordlist_var.get().strip()
            self.results["subdomains"] = subdomain_enum(t, wl, lambda m: self._log(m))
            self.results["ports"]      = port_scanner(t, lambda m: self._log(m))
            self._log("\n  ✔ All modules done!\n", "green")
            self._update_stats()
            self._busy(False)
        self._thread(_go)

    def _save_report(self):
        t = self._get_target()
        if not t: return
        if not self.results:
            messagebox.showinfo("No Data", "Run at least one module before saving a report.")
            return
        path = generate_report(t, self.results)
        messagebox.showinfo("Report Saved", f"Report saved to:\n{os.path.abspath(path)}")
        self.status_var.set(f"  Report saved → {path}")


# ─────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    app = OSINTApp(root)
    root.mainloop()
